<?php
$lang['payment_gateway_pesapal_consumer_key'] = 'Live Consumer Key';
$lang['payment_gateway_pesapal_consumer_secret'] = 'Live Consumer Secret';
$lang['payment_gateway_pesapal_consumer_key_demo'] = 'Demo Consumer Key';
$lang['payment_gateway_pesapal_consumer_secret_demo'] = 'Demo Consumer Secret';

$lang['payment_gateway_pesapal_type'] = 'Type';
$lang['payment_gateway_pesapal_currency'] = '<i class="fa fa-question-circle" data-toggle="tooltip" data-title="Please Note: PesaPal will request payment from the customer in the currency you specified where possible. If the payment option the customer selects does not support that currency, PesaPal will convert the amount using the day\'s exchange rate and present the amount in the local currency to the user. DO NOT ADD MULTIPLE CURRENCIES HERE" data-original-title="" title=""></i> Currency';
